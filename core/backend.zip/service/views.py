
from django.shortcuts import render
from django.shortcuts import get_object_or_404
from django.contrib.auth.models import User
from django.utils import timezone
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.tokens import AccessToken, RefreshToken
from rest_framework import status
from rest_framework.decorators import action
from rest_framework.decorators import api_view
from rest_framework.viewsets import ViewSet
from service.utils import generate_otp, send_otp_via_sms
from service.models import Profile
from service.models import PhoneOTP
from service.models import ServiceRequest
from service.models import Technician
from service.models import Device
from service.serializers import SendOTPSerializer
from service.serializers import VerifyOTPSerializer
from service.serializers import ServiceRequestSerializer
from service.serializers import ProfileSerializer
from service.serializers import TechnicianSerializer
from service.serializers import DeviceSerializer


from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync

import logging


logger = logging.getLogger(__name__)


class CustomTokenRefreshView(TokenRefreshView):
    pass  # Uses default behavior

class CustomTokenObtainPairView(TokenObtainPairView):
    pass  # Uses default behavior

class SendOTPAPIView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        print(__name__)
        serializer = SendOTPSerializer(data=request.data)
        if serializer.is_valid():
            phone_number = serializer.validated_data['phone_number']
            otp = generate_otp()
            # send_otp_via_sms(phone_number, otp)
            PhoneOTP.objects.update_or_create(
                phone_number=phone_number,
                defaults={'otp': otp, 'created_at': timezone.now(), 'is_verified': False}
            )
            logger.info(f"OTP {otp} sent to {phone_number}")
            print(f"OTP {otp} sent to {phone_number}")
            return Response({"message": "OTP sent successfully."}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class VerifyOTPAPIView(APIView):
    def post(self, request, *args, **kwargs):
        serializer = VerifyOTPSerializer(data=request.data)
        if serializer.is_valid():
            phone_number = serializer.validated_data['phone_number']
            otp = serializer.validated_data['otp']
            try:
                otp_record = PhoneOTP.objects.get(phone_number=phone_number, otp=otp)
            except PhoneOTP.DoesNotExist:
                return Response({"error": "Invalid OTP"}, status=400)
            
            if otp_record.is_verified:
                otp_record.delete()
                return Response({"error": "OTP already used"}, status=400)
            
            if otp_record.is_expired():
                otp_record.delete()
                return Response({"error": "OTP has expired"}, status=400)

            
            user, created = User.objects.get_or_create(username=phone_number)
            
            if created:
                print("User created:", user)
                user.set_unusable_password()
                user.save()
            
            
            profile, created = Profile.objects.get_or_create(user=user)
            profile.save()
            access_token = AccessToken.for_user(user)
            refresh_token = RefreshToken.for_user(user)
            otp_record.delete()
            return Response({"access_token": str(access_token), "refresh_token": str(refresh_token)}, status=201)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)





class ServiceView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]
    
    
    def get(self, request):
        print("ServiceView get method called")
        print(request.user)
        user = get_object_or_404(User, id=request.user.id)
        print(user)
        profile = get_object_or_404(Profile, user=user)
        service_requests = ServiceRequest.objects.filter(profile=profile).order_by('-created_at')
        serializer = ServiceRequestSerializer(service_requests, many=True)
        return Response(serializer.data, status=200)
    
    
    def post(self, request):
        user = get_object_or_404(User, id=request.user.id)
        print(user)
        profile = get_object_or_404(Profile, user=user)
        serializer = ServiceRequestSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(profile=profile)
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)


class ServiceDetailView(APIView):
    # permission_classes = [IsAuthenticated]
    # authentication_classes = [JWTAuthentication]
    
    
    def get(self, request, pk):
        service_request = get_object_or_404(ServiceRequest, pk=pk,)
        serializer = ServiceRequestSerializer(service_request)
        return Response(serializer.data, status=200)

    def delete(self, request, pk):
        user = get_object_or_404(User, id=request.user.id)
        profile = get_object_or_404(Profile, user=user)
        service_request = get_object_or_404(ServiceRequest, pk=pk, profile=profile)
        service_request.delete()
        return Response(status=204)

class UserProfileView(APIView):
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]    

    def get(self, request):
        return Response({"message": "User profile data"}, status=200)
    

class SendTechnicianOTPAPIView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = SendOTPSerializer(data=request.data)
        if serializer.is_valid():
            phone_number = serializer.validated_data['phone_number']
            user = User.objects.filter(username=phone_number).first()
            if user is None:
                return Response({"error": "Technician does not exist"}, status=400)
                # send_otp_via_sms(phone_number, otp)
                
            tech = Technician.objects.filter(user=user).first()
            if tech is not None:    
                otp = generate_otp()
                
                PhoneOTP.objects.update_or_create(
                    phone_number=phone_number,
                    defaults={'otp': otp, 'created_at': timezone.now(), 'is_verified': False}
                )
                logger.info(f"OTP {otp} sent to {phone_number}")
                print(f"OTP {otp} sent to {phone_number}")
                return Response({"message": "OTP sent successfully."}, status=status.HTTP_200_OK)
            if tech is None:
                return Response({"error": "Technician does not exist"}, status=400)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        
class VerifyTechnicianOTPAPIView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = VerifyOTPSerializer(data=request.data)
        if serializer.is_valid():
            phone_number = serializer.validated_data['phone_number']
            otp = serializer.validated_data['otp']
            try:
                otp_record = PhoneOTP.objects.get(phone_number=phone_number, otp=otp)
            except PhoneOTP.DoesNotExist:
                return Response({"error": "Invalid OTP"}, status=400)
            
            if otp_record.is_verified:
                otp_record.delete()
                return Response({"error": "OTP already used"}, status=400)
            
            if otp_record.is_expired():
                otp_record.delete()
                return Response({"error": "OTP has expired"}, status=400)

            user = User.objects.filter(username=phone_number).first()
            
            if user is None:
                
                return Response({"error": "Technician does not exist"}, status=400)
                
            tech = Technician.objects.filter(user=user).first()
            if tech is not None:    
                print("Technician created:", user)
                access_token = AccessToken.for_user(user)
                refresh_token = RefreshToken.for_user(user)
                return Response({
                    "access_token": str(access_token),
                    "refresh_token": str(refresh_token)}, status=status.HTTP_200_OK)
            
            otp_record.delete()
            return Response({"message": "Technician verified successfully."}, status=201)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)




class RequestsView(ViewSet):
    permission_classes = [IsAuthenticated]
    authentication_classes = [JWTAuthentication]
    
    def list(self, request):
        requests = ServiceRequest.objects.all().order_by('-created_at')
        serializer = ServiceRequestSerializer(requests, many=True)
        return Response(serializer.data, status=200)
    
    
    @action(detail=False, methods=['get'])
    def unassigned(self, request):
        queryset = ServiceRequest.objects.filter(technician=None).order_by('-created_at')
        serializer = ServiceRequestSerializer(queryset, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def mine(self, request):
        queryset = ServiceRequest.objects.filter(technician=request.user.technician).order_by('-created_at')
        serializer = ServiceRequestSerializer(queryset, many=True)
        return Response(serializer.data)
    
    
    @action(detail=True, methods=['post'])
    def assign(self, request, pk=None):
        service_request = get_object_or_404(ServiceRequest, pk=pk)
        user = get_object_or_404(User, id=request.user.id)
        technician = get_object_or_404(Technician, user=user)
        service_request.technician = technician
        service_request.teaken = True
        service_request.save()
        serializer = ServiceRequestSerializer(service_request)
        return Response(serializer.data, status=200)
    
    @action(detail=True, methods=['post'])
    def getbyid(self, request, pk=None):
        service_request = get_object_or_404(ServiceRequest, pk=pk)
        serializer = ServiceRequestSerializer(service_request)
        return Response(serializer.data, status=200)
    
    
    @action(detail=True, methods=['post'])
    def change_status(self, request, pk=None):
        service_request = get_object_or_404(ServiceRequest, pk=pk)
        status = request.data.get('status')
        if status:
            service_request.status = status
            service_request.save()
            serializer = ServiceRequestSerializer(service_request)
            return Response(serializer.data, status=200)
        return Response({"error": "Status not provided"}, status=400)
    
    @action(detail=True, methods=['post'])
    def complete(self, request, pk=None):
        service_request = get_object_or_404(ServiceRequest, pk=pk)
        service_request.completed = True
        service_request.save()
        serializer = ServiceRequestSerializer(service_request)
        return Response(serializer.data, status=200)


@api_view(['GET'])
def get_devices(request):
    devices = Device.objects.all().order_by('name')
    serializer = DeviceSerializer(devices, many=True)
    return Response(serializer.data, status=200)






def send_service_complete_notification(request, user_id):
    """
    Function to send a notification to the user when the service is marked as completed.
    """
    # Assuming you have a function to get the channel layer
    channel_layer = get_channel_layer()
    async_to_sync(channel_layer.group_send)(
        f"user_{user_id}",
        {
            'type': 'send_service_complete',
            'message': 'Service has been marked completed',
        }
    )
