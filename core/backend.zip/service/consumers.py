# consumers.py
from channels.generic.websocket import WebsocketConsumer
import json

class ServiceRequestConsumer(WebsocketConsumer):
    def connect(self):
        print("Connected to the service request channel")
        self.accept()
        self.send(text_data=json.dumps({
            'message': 'Connected to the service request channel',
        }))

    # def disconnect(self, close_code):
    #     await self.channel_layer.group_discard(
    #         self.room_group_name,
    #         self.channel_name
    #     )

    # async def send_service_complete(self, event):
    #     await self.send(text_data=json.dumps({
    #         'message': 'Service has been marked completed',
    #     }))
