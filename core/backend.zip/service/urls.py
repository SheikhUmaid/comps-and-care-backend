from django.urls import path
from rest_framework.routers import DefaultRouter

from service.views import (
    #class based views
    CustomTokenObtainPairView,
    CustomTokenRefreshView,
    SendOTPAPIView,
    VerifyOTPAPIView,
    UserProfileView, 
    ServiceView,
    ServiceDetailView,
    SendTechnicianOTPAPIView,
    VerifyTechnicianOTPAPIView,
    RequestsView,
    
    #function based views
    get_devices,
)


router = DefaultRouter()
router.register(r'tech/requests', RequestsView, basename='request')




urlpatterns = [
    path('refresh/', CustomTokenRefreshView.as_view(), name='token_refresh'),
    
    #user
    path('send-otp/', SendOTPAPIView.as_view(), name='register'),
    path('verify-otp/', VerifyOTPAPIView.as_view(), name='verify'),
    path('user/', UserProfileView.as_view(), name='user_profile'),
    path('service/', ServiceView.as_view(), name='service_request'),
    path('service/<int:pk>/', ServiceDetailView.as_view(), name='service_request_detail'),
    path('devices/', get_devices, name='get_devices'),
    
    
    #technician
    path('tech/send-otp/', SendTechnicianOTPAPIView.as_view(), name='send_technician_otp'),
    path('tech/verify-otp/', VerifyTechnicianOTPAPIView.as_view(), name='verify_technician_otp'),
    path('tech/service/<int:pk>/', ServiceDetailView.as_view(), name='service_request_detail'),
    # path('tech/requests/', RequestsView.as_view(), name='technician_requests'),
    
]+ router.urls