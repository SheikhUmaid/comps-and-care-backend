from rest_framework import serializers
from service.models import PhoneOTP, Profile, Technician, ServiceRequest, Device
from django.contrib.auth.models import User



class SendOTPSerializer(serializers.Serializer):
    phone_number = serializers.CharField(max_length=15, required=True)

class VerifyOTPSerializer(serializers.Serializer):
    phone_number = serializers.CharField(max_length=15, required=True)
    otp = serializers.CharField(max_length=6, required=True)


class DeviceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Device
        fields = ['id', 'name', 'price']
        read_only_fields = ['id']  # Make this field read-only

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username']
        read_only_fields = ['id']  # Make this field read-only

class ProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    
    class Meta:
        model = Profile
        fields = ['id', 'user',]
        read_only_fields = ['id']  # Make this field read-only

class TechnicianSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    
    class Meta:
        model = Technician
        fields = ['id', 'user',]
        read_only_fields = ['id']  # Make this field read-only

class DeviceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Device
        fields = ['id', 'name', 'price']
        read_only_fields = ['id']  # Make this field read-only


class ServiceRequestSerializer(serializers.ModelSerializer):
    profile = ProfileSerializer(read_only=True)
    technician = TechnicianSerializer(read_only=True)
    # devices = DeviceSerializer(many=True, read_only=True)
    devices = serializers.PrimaryKeyRelatedField(
        many=True,
        queryset=Device.objects.all()
    )
    class Meta:
        model = ServiceRequest
        fields = ['id', 'profile', 'technician', 'devices', 'location', 'description','address','date', 'timeslot', 'status', 'taken', 'completed', 'created_at', 'updated_at']
        read_only_fields = ['id', 'profile', 'created_at', 'updated_at']  # Make these fields read-only
        
    # populate the user field
    
    def to_representation(self, instance):
        data = super().to_representation(instance)
        data['devices'] = DeviceSerializer(instance.devices.all(), many=True).data
        return data
