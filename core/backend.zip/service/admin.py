from django.contrib import admin
from service.models import Profile, PhoneOTP, Technician, ServiceRequest, Device
# Register your models here.

admin.site.register(Profile)
admin.site.register(PhoneOTP)
admin.site.register(Technician)
admin.site.register(ServiceRequest)
admin.site.register(Device)